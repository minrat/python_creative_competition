import os
import pygame
from pygame.locals import *


class TicTacToe:
    def __init__(self, player_name):
        # 玩家信息接收
        self.show_player = player_name

        # 初始化
        pygame.init()
        pygame.display.set_caption("创意竞赛-井字棋")

        # 设置窗体大小
        self.screen = pygame.display.set_mode((600, 400))

        # 背景颜色
        self.screen.fill((255, 255, 255))

        # 初始化游戏状态
        self.running = True

        # 保存棋子位置坐标集合
        self.chess_locations = {(row, column): None for row in range(1, 4) for column in range(1, 4)}

        # 棋盘坐标位置
        self.chess_position_x, self.chess_position_y = 200, 150

        # 额外案件检查
        self.key_status = ""

    # 增加文字
    def show_text(self, text, position_x, position_y, text_height=40):
        # 字体颜色
        font_color = (0, 0, 0)
        # 字体背景颜色
        background_color = (255, 255, 255)
        # 字体
        font_path = os.getcwd()+"/Arial.ttf"
        # 设置字体格式
        text_font = pygame.font.Font(font_path, text_height)
        # 设置显示的目标文字
        text_content = text_font.render(text, True, font_color, background_color)
        # 获取显示的目标载体
        text_location = text_content.get_rect()
        # 设置显示的坐标位置
        text_location.center = (position_x, position_y)
        # 将文字内容写到目标位置
        self.screen.blit(text_content, text_location)

    # 判断胜负
    def check_wining(self):
        '''
        井字棋的胜负判断方法:
        1.X 轴方向,三个内容相同
        2.Y 轴方向,三个内容相同
        3. 对角线方向, 三个内容相同
        :return:
        '''
        flag = ""
        for i in range(3):
            # 判断 X 轴方向
            if self.chess_locations[(1, i + 1)] == self.chess_locations[(2, i + 1)] == self.chess_locations[(3, i + 1)] is not None:
                flag = self.chess_locations[(1, i + 1)]
                break
            # 判断 Y 轴方向
            if self.chess_locations[(i+1, 1)] == self.chess_locations[(i+1, 2)] == self.chess_locations[(i+1, 3)] is not None:
                flag = self.chess_locations[(i+1, 1)]
                break
        # 判断对角线
        if self.chess_locations[(1, 1)] == self.chess_locations[(2, 2)] == self.chess_locations[(3, 3)] is not None:
            flag = self.chess_locations[(1, 1)]
        # 判断对角线
        if self.chess_locations[(1, 3)] == self.chess_locations[(2, 2)] == self.chess_locations[(3, 1)] is not None:
            flag = self.chess_locations[(1, 3)]
        return flag

    # 划线
    def draw_line(self):
        # 起点坐标
        x_start, y_start = 0, 0
        # 终点坐标
        x_end, y_end = 0, 0
        # 根据输赢判断,获取划线的起点及终点坐标
        for i in range(3):
            # X 轴方向判断
            if self.chess_locations[(1, i+1)] == self.chess_locations[(2, i+1)] == self.chess_locations[(3, i+1)] is not None:
                x_start, y_start = self.chess_position_x + (i)*64+37, self.chess_position_y - 40
                x_end, y_end = self.chess_position_x + (i)*64+37, self.chess_position_y + 242
                break

            # Y 轴方向判断
            if self.chess_locations[(i+1, 1)] == self.chess_locations[(i+1, 2)] == self.chess_locations[(i+1, 3)] is not None:
                x_start, y_start = self.chess_position_x - 40, self.chess_position_y + (i)*64+37
                x_end, y_end = self.chess_position_x + 242, self.chess_position_y + (i)*64+37
                break

        # 对角线方向
        if self.chess_locations[(1, 1)] == self.chess_locations[(2, 2)] == self.chess_locations[(3, 3)] is not None:
            x_start, y_start = self.chess_position_x - 40, self.chess_position_y - 40
            x_end, y_end = self.chess_position_x + 242, self.chess_position_y + 242

        # 对角线方向
        if self.chess_locations[(1, 3)] == self.chess_locations[(2, 2)] == self.chess_locations[(3, 1)] is not None:
            x_start, y_start = self.chess_position_x - 20, self.chess_position_y + 222
            x_end, y_end = self.chess_position_x + 222, self.chess_position_y - 20

        # 划线(获胜路径)
        pygame.draw.line(self.screen, (255, 0, 0), (x_start, y_start), (x_end, y_end), 4)

    # 落棋子到目标坐标
    def put_chess(self, content, row, column):
        # 已有棋子
        if self.chess_locations[(row, column)] is not None:
            return False
        else:
            self.chess_locations[(row, column)] = content
            return True

    # 画所有的棋子
    def draw_chess(self):
        for (row, column) in self.chess_locations:
            self.chess(self.chess_locations[(row, column)], row, column)

    # 获取落棋子的坐标
    def get_position(self, row, column):
        return self.chess_position_x + 37 + 64 * (column - 1), self.chess_position_y + 37 + 64 * (row - 1)

    # 坐标校验(是否越界)
    def position_verify(self, x, y):
        return (
            ((self.chess_position_x + 10 < x < self.chess_position_x + 10 + 54) + 2*(self.chess_position_x + 20 + 54 < x < self.chess_position_x + 20 + 2 * 54) + 3*(
                    self.chess_position_x + 30 + 2 * 54 < x < self.chess_position_x + 30 + 3 * 54)),
            ((self.chess_position_y + 10 < y < self.chess_position_y + 10 + 54) + 2*(self.chess_position_y + 20 + 54 < y < self.chess_position_y + 20 + 2 * 54) + 3*(
                    self.chess_position_y + 30 + 2 * 54 < y < self.chess_position_y + 30 + 3 * 54)))

    # 棋盘
    def chessboard(self, x, y):
        '''
    　　用法: pygame.draw.rect(<target>, color, Rect, width=0): return Rect
    　　理解: 在<target>上绘制矩形，第二个参数是线条（或填充）的颜色，第三个参数Rect的形式是((x, y), (width, height))，
                表示的是所绘制矩形的区域，其中第一个元组(x, y)表示的是该矩形左上角的坐标，
                第二个元组 (width, height)表示的是矩形的宽度和高度。
                width表示线条的粗细，单位为像素；默认值为0，表示填充矩形内部。
        '''
        # 底色
        pygame.draw.rect(self.screen, (0, 128, 0), Rect(x, y, 202, 202))
        # 单元格
        for i in range(9):
            pygame.draw.rect(self.screen, (255, 255, 255), Rect(x + 10 + (i % 3) * 64, y + 10 + (i // 3) * 64, 54, 54))

    # 绘制棋子位置
    def chess(self, content, row, column):
        if content == "o":
            # 绘制 O 图案
            pygame.draw.circle(self.screen, (0, 0, 0), self.get_position(row, column), 20, 3)
        elif content == "x":
            x, y = self.get_position(row, column)
            # 绘制 X 图案
            pygame.draw.line(self.screen, (0, 0, 0), (x - 18, y - 18), (x + 18, y + 18), 3)
            pygame.draw.line(self.screen, (0, 0, 0), (x + 18, y - 18), (x - 18, y + 18), 3)

    # 开始游戏
    def start_game(self):
        i = 0
        while self.running:
            # 1，判断执行游戏状态
            for self.key_status in pygame.event.get():
                if self.key_status.type == KEYDOWN:
                    # 退出游戏
                    if self.key_status.key == K_q:
                        self.running = False
                    # 重新开始
                    if self.key_status.key == K_r:
                        i = 0
                        # 重新构建棋盘
                        self.chess_locations = {(row, column): None for row in range(1, 4) for column in range(1, 4)}
                        # show_text("The Game Ended In A Draw", 399, 100, 48, (255, 255, 255))
                        pygame.draw.rect(self.screen, (255, 255, 255), (1, 1, 800, 600))
                if self.key_status.type == QUIT:
                    self.running = False

            # 若鼠标点击，将棋落到chess_locations 数组(列表)
            cursor_x, cursor_y = pygame.mouse.get_pos()
            # 获取鼠标按钮的状态。
            # 当左键按下的时候btn_one 的值会被赋值为1，鼠标按键弹起是会被赋值为0。
            btn_one, btn_two, btn_three = pygame.mouse.get_pressed()
            show_content = "x"
            row, column = 1, 1
            if btn_one and i < 9:
                if i % 2 == 0:
                    row, column = self.position_verify(cursor_x, cursor_y)
                    show_content = "x"
                elif i % 2 == 1:
                    row, column = self.position_verify(cursor_x, cursor_y)
                    show_content = "o"
                if row == 0 or column == 0:
                    continue
                if self.put_chess(show_content, column, row):
                    i += 1

            # 画棋盘和棋子
            self.chessboard(self.chess_position_x, self.chess_position_y)
            # 游戏玩家显示
            self.show_text("welcome: "+self.show_player+" ", 500, 20, 20)
            # 游戏退出提示
            self.show_text("'q': Quit", 80, 20, 20)
            # 游戏重新开始提示
            self.show_text("'r': Restart", 80, 50, 20)
            # 获取判断获胜函数结果
            if self.check_wining() is not "":
                # 显示获胜信息
                self.show_text("[ "+self.check_wining()+" ] PASS", 340, 90)
                # 划线
                self.draw_line()
                i = 9
            elif i == 9 and self.check_wining() is "":
                self.show_text("End In Tie", 340, 90)
            self.draw_chess()

            # 刷新
            pygame.display.update()