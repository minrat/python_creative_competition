from tkinter import *
from tkinter.messagebox import *
from tkinter.scrolledtext import ScrolledText
from tkinter import filedialog
import base64

'''
界面需要根据个人喜好美化一下
'''

class TextRank(object):
    def __init__(self, master=None, user_account=None):
        self.root = master
        # 设置标题
        self.root.title("加密记事本-文本分析")
        # 设置框体
        # self.root.geometry('800x600')
        # 单元框架
        self.frame_text = Frame(self.root)

        # 默认信息
        self.default_content = '''我喜欢人工智能，希望通过学习 python 人工智能，了解当前科技发展的动向。
                当前学习的是机器学习的底层实现算法，通过学习，了解到机器学习主要分为：原始数据准备、样本数据加工、目标数据预测三部分。 '''
        self.default_encrypt_content = ""
        # 显示用户
        Label(self.frame_text, text="欢迎您,[ "+user_account+" ]").grid(row=1, column=20, columnspan=2)
        # 记录用户名
        self.username = user_account

        # 文本输入标签
        Label(self.frame_text, text="请输入文本:").grid(row=5, column=0, columnspan=4)

        # 多行文本框: 输入内容
        self.entry_content = ScrolledText(self.frame_text, width=50, height=15)
        self.entry_content.config(state="normal")
        self.entry_content.grid(row=5, column=5, columnspan=4)

        # 设置默认信息
        self.entry_content.insert(INSERT, self.default_content)

        Label(self.frame_text, text="* ,必填", bg='#FFFF00', fg='#FF0000').grid(row=5, column=9, columnspan=4)

        # 分析按钮
        self.button_commit = Button(self.frame_text, text="分析", command=self.calculate_and_show).grid(row=6, column=3,
                                                                                                      columnspan=4)
        # 加密按钮
        self.button_commit_encrypy = Button(self.frame_text, text="加密", command=self.encrypt).grid(row=6, column=5,
                                                                                                   columnspan=4)
        # 保存按钮
        self.button_commit_save = Button(self.frame_text, text="保存", command=self.save).grid(row=6, column=7,
                                                                                                   columnspan=4)

        # 密文显示区域
        # 加密&解密文本 使用异或运算来实现或者使用base64方式，当前选取异或运算
        # 文本输入标签
        Label(self.frame_text, text="密文内容:").grid(row=8, column=0, columnspan=4)

        # 多行文本框: 输入内容
        self.entry_content_encrypt = ScrolledText(self.frame_text, width=50, height=15)
        # 起始禁止用户输入内容
        self.entry_content_encrypt.config(state=DISABLED)
        self.entry_content_encrypt.grid(row=8, column=5, columnspan=4)

        # 设置默认信息
        self.entry_content_encrypt.insert(INSERT, self.default_encrypt_content)

        Label(self.frame_text, text="* ,解密时必填", bg='#FFFF00', fg='#FF0000').grid(row=8, column=9, columnspan=4)

        # 加载文件按钮
        self.button_commit_load = Button(self.frame_text, text="打开", command=self.load).grid(row=9, column=3,
                                                                                                   columnspan=4)
        # 解密按钮
        self.button_commit_decrypt = Button(self.frame_text, text="解密", command=self.decrypt).grid(row=9, column=5,
                                                                                                      columnspan=4)
        # 返回按钮
        self.button_commit = Button(self.frame_text, text="返回", command=self.back_home).grid(row=9, column=7,
                                                                                             columnspan=4)
        # 框体容器统一打包至窗体对象
        self.frame_text.pack(side=TOP, expand=YES)

    # TextRank 值分析计算
    def calculate_and_show(self):
        # 获取文本框内容
        content = self.entry_content.get(1.0, INSERT)
        if content.strip() == "":
            showerror("错误", "文本框不能为空")
        else:
            # 引入Jieba 分析计算
            from Privacy_Jieba import TextRankCal

            # 启用分析
            pr = TextRankCal(content)
            pr.cut_sentence()
            pr.create_nodes()
            pr.create_matrix()
            pr.use_rank()
            results = pr.show_result()
            pr.jieba_paint(results)

    # 文本加密
    def encrypt(self):
        print("文本加密")
        source_content = self.entry_content.get('0.0', 'end')

        # base64加密
        bytes_content = source_content.encode("utf-8")
        str_out = base64.b64encode(bytes_content)
        encrypt_content = str(str_out)[2:-1]

        # 开启密文区域显示
        self.entry_content_encrypt.config(state=NORMAL)

        # 密文区域-清空
        self.entry_content_encrypt.delete('0.0', 'end')
        # 密文区域-显示信息
        self.entry_content_encrypt.insert(INSERT, encrypt_content)

        # 处理完成，禁止用户输入内容
        self.entry_content_encrypt.config(state=DISABLED)

    # 文件保存
    def save(self):
        print("文件保存")
        # 保存文件，确认是否为空
        crypt_content = self.entry_content_encrypt.get('0.0', 'end')
        if crypt_content.strip() == "":
            showerror("错误", "请先执行加密 或者 加载密文！")
        else:
            # 启用文件保存插件
            file_save = filedialog.asksaveasfilename(title='文件保存',
                                                     initialdir=r'.',
                                                     initialfile='decrypt.ept', filetypes=[(".ept", ".EPT")])
            if file_save.strip() == "":
                showwarning("WARNING", "请输入保存文件位置以及名称！！！")
            else:
                try:
                    # 将文本打开，写入密文内容
                    fo = open(file_save, "w+", encoding='utf-8')
                    fo.write(crypt_content)
                except EXCEPTION:
                    showerror("ERROR", "文件保存出错，请确认后再试")
                finally:
                    fo.close()

    # 文本解密
    def decrypt(self):
        print("文本解密")
        decrypt_content = self.entry_content_encrypt.get('0.0', 'end')

        # 对输入密码进行加密比对，或者对提取出的密码进行解密操作
        source_content = base64.b64decode(decrypt_content).decode("utf-8")

        # 明文区域-清空
        self.entry_content.delete('0.0', 'end')
        # 原文区域-显示信息
        self.entry_content.insert(INSERT, source_content)

    # 文件加载
    def load(self):
        print("文件加载")
        # 启用文件打开插件
        file_load = filedialog.askopenfilename(title='文件打开',
                                               filetypes=[('Encrypt', '*.ept *.pt'), ('All files', '*')])
        if file_load.strip() == "":
            showinfo("INFO","请确认打开文件")
        else:
            try:
                # 将文本打开，读入文件内容
                fo = open(file_load, "r+", encoding='utf-8')
                file_load_content = fo.read()
                # 开放用户输入内容
                self.entry_content_encrypt.config(state=NORMAL)

                # 密文区域-加载显示信息
                self.entry_content_encrypt.insert(INSERT, file_load_content)
            except EXCEPTION:
                showerror("ERROR", "文件保存出错，请确认后再试")
            finally:
                fo.close()
                # 禁止用户输入内容
                self.entry_content_encrypt.config(state=DISABLED)

    # 返回主界面
    def back_home(self):
        # 注销当前功能界面
        self.frame_text.destroy()

        # 引入主功能界面
        from MainFrame import MainPage

        # 激活主功能界面
        MainPage(self.root, self.username)