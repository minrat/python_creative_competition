from tkinter import *
from PIL import ImageTk, Image

'''
程序主界面需要根据个人喜好美化一下
'''

class MainPage(object):
    def __init__(self, master=None, user_account=None):
        self.root = master
        # 设置标题
        self.root.title("加密记事本-功能选择")
        # 设置框体
        self.root.geometry('800x800')
        # 单元框架
        self.frame_main = Frame(self.root)

        # 显示用户
        Label(self.frame_main, text="欢迎您,[ "+user_account+" ]").grid(row=1, column=30, columnspan=2)
        Button(self.frame_main, text="退出", command=self.go_quit).grid(row=1, column=33, columnspan=2)

        # 记录用户名
        self.username = user_account

        # 菜单按钮
        img_pr_path = "images/notebook.gif"
        img_pr = Image.open(img_pr_path)
        photo_pr = ImageTk.PhotoImage(img_pr)
        Button(self.frame_main, text="PR值分析", image=photo_pr, command=self.go_pr_analyse).grid(row=5, column=3)

        # 天气预报-爬虫
        img_weather_path = "images/weather.gif"
        img_weather = Image.open(img_weather_path)
        photo_weather = ImageTk.PhotoImage(img_weather)
        Button(self.frame_main, text="天气爬虫", image=photo_weather, command=self.go_weather).grid(row=6, column=3)

        # 二维码生成
        img_game_path = "images/qrcode.gif"
        img_game = Image.open(img_game_path)
        photo_game = ImageTk.PhotoImage(img_game)
        Button(self.frame_main, text="二维码生成", image=photo_game, command=self.go_qrcode_generate).grid(row=7, column=3)

        # 背景
        img_bg_path = "images/frog.png"
        img_bg = Image.open(img_bg_path)
        photo_bg = ImageTk.PhotoImage(img_bg)
        Label(self.frame_main, text="", image=photo_bg).grid(row=5, column=15, rowspan=4, columnspan=5)

        # 框体容器统一打包
        self.frame_main.pack(anchor=W)
        self.root.mainloop()

    # PR值分析
    def go_pr_analyse(self):
        # 功能销毁
        self.frame_main.destroy()
        # 分词PR导入
        from Privacy_TextRank import TextRank
        # 功能启用
        TextRank(self.root, self.username)

    # 天气预报
    def go_weather(self):
        # 主功能界面销毁
        self.frame_main.destroy()

        # 天气预报引入
        from Privacy_Weather import Weather

        # 天气预报激活
        Weather(self.root, self.username)

    # 二维码生成
    def go_qrcode_generate(self):
        # 功能销毁
        self.frame_main.destroy()

        # 二维码引入
        from Privacy_qrcode import QRTool

        # 初始化二维码
        QRTool(self.root, self.username)


    # 退出程序
    def go_quit(self):
        # 销毁当前
        self.frame_main.destroy()
        # self.canvas.destroy()

        # 引入登录
        from Privacy_Login import Login
        Login(self.root)


# if __name__ == '__main__':
#     t = Tk()
#     p = MainPage(t, "hah")
#     t.mainloop()