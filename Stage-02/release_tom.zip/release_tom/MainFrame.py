from tkinter import *

'''
程序主界面需要根据个人喜好美化一下
'''

class MainPage(object):
    def __init__(self, master=None, user_account=None):
        self.root = master
        # 设置标题
        self.root.title("创意竞赛-功能选择")
        # 设置框体
        self.root.geometry('600x400')
        # 单元框架
        self.frame_main = Frame(self.root)

        # 显示用户
        Label(self.frame_main, text="欢迎您,[ "+user_account+" ]").grid(row=1, column=0, columnspan=2)
        # 记录用户名
        self.username = user_account

        # 菜单按钮
        Button(self.frame_main, text="PR值分析", command=self.go_pr_analyse).grid(row=5, column=3, columnspan=2)

        # 天气预报-爬虫
        Button(self.frame_main, text="天气预报", command=self.go_weather).grid(row=6, column=3, columnspan=2)

        # 游戏-井字棋
        Button(self.frame_main, text="游戏天地", command=self.go_game_tictactoe).grid(row=8, column=3, columnspan=2)

        # 框体容器统一打包
        self.frame_main.pack(anchor=W)

    # 趣味画像
    def go_pr_analyse(self):
        # 功能销毁
        self.frame_main.destroy()
        # 分词PR导入
        from Competition_TextRank import TextRank
        # 功能启用
        TextRank(self.root, self.username)

    # 天气预报
    def go_weather(self):
        # 主功能界面销毁
        self.frame_main.destroy()

        # 天气预报引入
        from Competition_Weather import Weather

        # 天气预报激活
        Weather(self.root, self.username)

    # 游戏天地
    def go_game_tictactoe(self):
        # 游戏引入
        from Game_TicTacToe import TicTacToe
        # 初始化游戏对象
        game = TicTacToe(self.username)
        # 执行开始游戏
        game.start_game()
