from tkinter import *
from Privacy_Login import *

if __name__ == '__main__':
    # 实例化对象
    root = Tk()

    # 设置窗体居中显示
    # # 窗体大小
    windows_weight = 800
    windows_height = 600

    # #  显示位置
    screen_location_weight = (root.winfo_screenwidth() - windows_weight)/2
    screen_location_height = (root.winfo_screenheight() - windows_height)/2

    # # 设置显示
    root.geometry('%dx%d+%d+%d' % (windows_weight, windows_height, screen_location_weight, screen_location_height))

    # 加载具体内容，首先登录功能
    Login(root)

    # 后台循环执行
    root.mainloop()