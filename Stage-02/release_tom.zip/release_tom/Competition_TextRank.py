from tkinter import *
from tkinter.messagebox import *
from tkinter.scrolledtext import ScrolledText

'''
界面需要根据个人喜好美化一下
'''

class TextRank(object):
    def __init__(self, master=None, user_account=None):
        self.root = master
        # 设置标题
        self.root.title("创意竞赛-TextRank")
        # 设置框体
        self.root.geometry('600x400')
        # 单元框架
        self.frame_text = Frame(self.root)

        # 默认信息
        self.default_content = '''我喜欢人工智能，希望通过学习 python 人工智能，了解当前科技发展的动向。
                当前学习的是机器学习的底层实现算法，通过学习，了解到机器学习主要分为：原始数据准备、样本数据加工、目标数据预测三部分。 '''
        # 显示用户
        Label(self.frame_text, text="欢迎您,[ "+user_account+" ]").grid(row=1, column=20, columnspan=2)
        # 记录用户名
        self.username = user_account

        # 文本输入标签
        Label(self.frame_text, text="请输入文本:").grid(row=5, column=0, columnspan=4)

        # 多行文本框: 输入内容
        self.entry_content = ScrolledText(self.frame_text, width=50, height=15)
        self.entry_content.config(state="normal")
        self.entry_content.grid(row=5, column=5, columnspan=4)

        # 设置默认信息
        self.entry_content.insert(INSERT, self.default_content)

        Label(self.frame_text, text="* ,必填", bg='#FFFF00', fg='#FF0000').grid(row=5, column=9, columnspan=4)

        # 确认按钮
        self.button_commit = Button(self.frame_text, text="分析", command=self.calculate_and_show).grid(row=6, column=5,columnspan=4)
        self.button_commit = Button(self.frame_text, text="返回", command=self.back_home).grid(row=6, column=7, columnspan=4)

        # 框体容器统一打包至窗体对象
        self.frame_text.pack(side=TOP, expand=YES)

    # TextRank 值分析计算
    def calculate_and_show(self):
        # 获取文本框内容
        content = self.entry_content.get(1.0, INSERT)
        if content.strip() == "":
            showerror("错误", "文本框不能为空")
        else:
            # 引入Jieba 分析计算
            from Competition_Jieba import TextRankCal

            # 启用分析
            pr = TextRankCal(content)
            pr.cut_sentence()
            pr.create_nodes()
            pr.create_matrix()
            pr.use_rank()
            results = pr.show_result()
            pr.jieba_paint(results)

    # 返回主界面
    def back_home(self):
        # 注销当前功能界面
        self.frame_text.destroy()

        # 引入主功能界面
        from MainFrame import MainPage

        # 激活主功能界面
        MainPage(self.root, self.username)