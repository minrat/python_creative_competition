# -*- coding: utf-8 -*-

'''
使用说明：
    仅需要更改查询目标地名称
'''

import json
from tkinter import *
from tkinter.messagebox import *

import urllib.request

class Weather(object):
    def __init__(self, master=None, username=None):
        # 接收用户名
        self.weather_user = username
        # 初始化
        self.root = master
        # 设置标题
        self.root.title("创意竞赛-天气预报")
        # 设置框体
        self.root.geometry('600x400')
        # 单元框架
        self.frame_weather = Frame(self.root)

        # 标签
        Label(self.frame_weather, text="欢迎:"+self.weather_user).grid(row=0, column=10, columnspan=2)

        Label(self.frame_weather, text="城市名称：").grid(row=1, column=0, columnspan=2)
        # 必填项标志(前景色,背景色)
        Label(self.frame_weather, text="( * ,必填,如:上海)", bg='#FFFF00', fg='#FF0000').grid(row=1, column=10, columnspan=2)
        Label(self.frame_weather, text="当前日期：").grid(row=2, column=0, columnspan=2)
        Label(self.frame_weather, text="PM 2.5：").grid(row=3, column=0, columnspan=2)
        Label(self.frame_weather, text="今日天气：").grid(row=4, column=0, columnspan=2)
        Label(self.frame_weather, text="明天天气：").grid(row=5, column=0, columnspan=2)
        Label(self.frame_weather, text="后天天气：").grid(row=6, column=0, columnspan=2)
        Label(self.frame_weather, text="穿衣指数：").grid(row=7, column=0, columnspan=2)
        Label(self.frame_weather, text="感冒指数：").grid(row=8, column=0, columnspan=2)
        Label(self.frame_weather, text="运动指数：").grid(row=9, column=0, columnspan=2)
        Label(self.frame_weather, text="紫外线指数：").grid(row=10, column=0, columnspan=2)

        # 填充位置
        Label(self.frame_weather, text=" ").grid(row=8, column=0, columnspan=2)
        Label(self.frame_weather, text=" ").grid(row=9, column=0, columnspan=2)

        # 对话框:城市名称
        self.entry_city = StringVar()
        Entry(self.frame_weather, textvariable=self.entry_city).grid(row=1, column=5, columnspan=4)

        # 对话框:当前日期
        self.entry_date = StringVar()
        self.date = Entry(self.frame_weather, textvariable=self.entry_date)
        self.date.config(state="disabled")
        self.date.grid(row=2, column=5, columnspan=4)

        # 对话框:PM2.5
        self.entry_pm25 = StringVar()
        self.pm25 = Entry(self.frame_weather, textvariable=self.entry_pm25)
        self.pm25.config(state="disabled")
        self.pm25.grid(row=3, column=5, columnspan=4)

        # 对话框:天气详情
        # 今天
        self.entry_weather_today = StringVar()
        self.entry_weather_today_detail = Entry(self.frame_weather, textvariable=self.entry_weather_today)
        self.entry_weather_today_detail.config(state="disabled")
        self.entry_weather_today_detail.grid(row=4, column=5, columnspan=4)

        # 明天
        self.entry_weather_tomorrow = StringVar()
        self.entry_weather_tomorrow_detail = Entry(self.frame_weather, textvariable=self.entry_weather_tomorrow)
        self.entry_weather_tomorrow_detail.config(state="disabled")
        self.entry_weather_tomorrow_detail.grid(row=5, column=5, columnspan=4)

        # 后天
        self.entry_weather_day_after_tomorrow = StringVar()
        self.entry_weather_day_after_tomorrow_detail = Entry(self.frame_weather, textvariable=self.entry_weather_day_after_tomorrow)
        self.entry_weather_day_after_tomorrow_detail.config(state="disabled")
        self.entry_weather_day_after_tomorrow_detail.grid(row=6, column=5, columnspan=4)

        # 贴士-穿衣指数
        self.entry_tips_cloth = StringVar()
        self.entry_tips_cloth_detail = Entry(self.frame_weather, textvariable=self.entry_tips_cloth)
        self.entry_tips_cloth_detail.config(state="disabled")
        self.entry_tips_cloth_detail.grid(row=7, column=5, columnspan=4)

        # 贴士-感冒指数
        self.entry_tips_cold = StringVar()
        self.entry_tips_cold_detail = Entry(self.frame_weather, textvariable=self.entry_tips_cold)
        self.entry_tips_cold_detail.config(state="disabled")
        self.entry_tips_cold_detail.grid(row=8, column=5, columnspan=4)

        # 贴士-运动指数
        self.entry_tips_sport = StringVar()
        self.entry_tips_sport_detail = Entry(self.frame_weather, textvariable=self.entry_tips_sport)
        self.entry_tips_sport_detail.config(state="disabled")
        self.entry_tips_sport_detail.grid(row=9, column=5, columnspan=4)

        # 贴士-紫外线指数
        self.entry_tips_rays = StringVar()
        self.entry_tips_rays_detail = Entry(self.frame_weather, textvariable=self.entry_tips_rays)
        self.entry_tips_rays_detail.config(state="disabled")
        self.entry_tips_rays_detail.grid(row=10, column=5, columnspan=4)

        Label(self.frame_weather, text="").grid(row=11, column=5, columnspan=4)
        Label(self.frame_weather, text="").grid(row=12, column=5, columnspan=4)

        # 确认按钮
        self.button_commit = Button(self.frame_weather, text="查询", command=self.get_weather_detail).grid(row=13, column=5, columnspan=4)
        self.button_commit = Button(self.frame_weather, text="返回", command=self.back_home).grid(row=13, column=7, columnspan=4)

        # 框体容器统一打包至窗体对象
        self.frame_weather.pack()

        # 使用百度提供的天气预报接口
        self.url = "http://api.map.baidu.com/telematics/v3/weather?output=json&"
        self.ak = "A5CGqctY5c0RwTfZFuktytfw"

        self.root.mainloop()

    def get_weather_detail(self):
        # 获取城市名称
        city = self.entry_city.get()
        # 开始处理结果
        if city.strip() == "":
            showerror("错误", "城市名称不能为空")
        else:
            url = self.url + 'location=' + urllib.parse.quote(city) + '&ak=' + self.ak
            response = urllib.request.urlopen(url).read()
            result = response.decode('utf-8')
            result = json.loads(result)

            # 查询返回日期
            date = result.get('date')
            self.entry_date.set(date)
            print("日 期："+date)
            result = dict(result['results'][0])

            # city
            city = result.get('currentCity')
            print("城 市： "+city)

            # pm25
            pm25 = result.get('pm25')
            self.entry_pm25.set(pm25)
            print("PM2.5： "+pm25)

            # 天气记录
            detail_today = []
            detail_tomorrow = []
            detail_day_after_tomorrow = []
            weather = result.get('weather_data')

            # 具体天气信息获取
            detail_today.append(weather[0].get('date') + " | " + weather[0].get('weather') +
                             " | " + weather[0].get('wind') + " | " + weather[0].get('temperature'))

            detail_tomorrow.append(weather[1].get('date') + " | " + weather[1].get('weather') +
                                " | " + weather[1].get('wind') + " | " + weather[1].get('temperature'))

            detail_day_after_tomorrow.append(weather[2].get('date') + " | " + weather[2].get('weather') +
                                " | " + weather[2].get('wind') + " | " + weather[2].get('temperature'))

            # 天气信息详情返回
            self.entry_weather_today.set(detail_today)
            self.entry_weather_tomorrow.set(detail_tomorrow)
            self.entry_weather_day_after_tomorrow.set(detail_day_after_tomorrow)

            # 贴士信息
            tips_cloth = []
            tips_cold = []
            tips_sport = []
            tips_rays = []

            # 获取贴士信息
            advice = result.get('index')

            tips_cloth.append(advice[0].get('zs'))
            tips_cold.append(advice[2].get('zs'))
            tips_sport.append(advice[3].get('zs'))
            tips_rays.append(advice[4].get('zs'))

            # 穿衣
            self.entry_tips_cloth.set(tips_cloth)
            # 感冒
            self.entry_tips_cold.set(tips_cold)
            # 运动
            self.entry_tips_sport.set(tips_sport)
            # 紫外线
            self.entry_tips_rays.set(tips_rays)

    # 返回主界面
    def back_home(self):
        # 注销当前功能界面
        self.frame_weather.destroy()

        # 引入主功能界面
        from MainFrame import MainPage

        # 激活主功能界面
        MainPage(self.root, self.weather_user)