from tkinter import *
from Competition_Login import *


if __name__ == '__main__':
    # 实例化对象
    root = Tk()
    # 加载登录功能
    Login(root)
    root.mainloop()