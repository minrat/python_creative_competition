from tkinter import *
from Competition_Login import *


if __name__ == '__main__':
    root = Tk()
    # 启用登录
    login = Login(root)
    root.mainloop()